<?php

declare(strict_types=1);

namespace Doctrine\ORM\Mapping;

interface ToOneAssociationMapping
{
}
